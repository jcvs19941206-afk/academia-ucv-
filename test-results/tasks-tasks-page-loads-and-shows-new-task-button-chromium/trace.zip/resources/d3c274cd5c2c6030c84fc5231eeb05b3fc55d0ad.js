(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_motion-dom_dist_es_0g6cuzy._.js","static/chunks/node_modules_framer-motion_dist_es_1_a7n4k._.js","static/chunks/node_modules_react-hook-form_dist_index_esm_mjs_0b0kr13._.js","static/chunks/node_modules_zod_v4_1ujpcun._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkg._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0q79z23._.js","static/chunks/node_modules_1sjqawe._.js","static/chunks/src_1z_b_qk._.js"],
    source: "dynamic"
});
